<?php
/**
 * AtendimentosCalendarForm Form
 * @author  <your name here>
 */
class AtendimentosCalendarFormView extends TPage
{
    private $fc;

    /**
     * Page constructor
     */
    public function __construct($param = null)
    {
        parent::__construct();

        $this->fc = new TFullCalendar(date('Y-m-d'), 'month');
        $this->fc->enableDays([1,2,3,4,5,6]);
        $this->fc->setReloadAction(new TAction(array($this, 'getEvents'), $param));
        $this->fc->setDayClickAction(new TAction(array('AtendimentosCalendarForm', 'onStartEdit')));
        $this->fc->setEventClickAction(new TAction(array('AtendimentosCalendarForm', 'onEdit')));
        $this->fc->setEventUpdateAction(new TAction(array('AtendimentosCalendarForm', 'onUpdateEvent')));
        $this->fc->setCurrentView('agendaWeek');
        $this->fc->setTimeRange('07:00', '19:00');
        $this->fc->enablePopover('Detalhes', "<b><center>Obs</center></b>
 {observacoes} 
<hr>
<b><center>Receiturario</center></b>
 {Receituario} ");
        $this->fc->setOption('slotTime', "00:30:00");
        $this->fc->setOption('slotDuration', "00:30:00");
        $this->fc->setOption('slotLabelInterval', 30);

        parent::add( $this->fc );
    }

    /**
     * Output events as an json
     */
    public static function getEvents($param=NULL)
    {
        $return = array();
        try
        {
            TTransaction::open('consultorio');

            $criteria = new TCriteria(); 

            $criteria->add(new TFilter('horaI', '<=', $param['end'].' 23:59:59'));
            $criteria->add(new TFilter('horaF', '>=', $param['start'].' 00:00:00'));

            $filterVar = TSession::getValue("userid");
            $criteria->add(new TFilter('IdMedicoUser', '=', $filterVar)); 

            $events = Atendimentos::getObjects($criteria);

            if ($events)
            {
                foreach ($events as $event)
                {
                    $event_array = $event->toArray();
                    $event_array['start'] = str_replace( ' ', 'T', $event_array['horaI']);
                    $event_array['end'] = str_replace( ' ', 'T', $event_array['horaF']);
                    $event_array['id'] = $event->id;
                    $event_array['color'] = $event->render("{CorStatus}");
                    $event_array['title'] = TFullCalendar::renderPopover($event->render("{paciente->nome} 
<br>
{fk_procedimento->Descricao} 
<br>
 {horaI} - {duracao}   "), $event->render("Detalhes"), $event->render("<b><center>Obs</center></b>
 {observacoes} 
<hr>
<b><center>Receiturario</center></b>
 {Receituario} "));

                    $return[] = $event_array;
                }
            }
            TTransaction::close();
            echo json_encode($return);
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }

    /**
     * Reconfigure the callendar
     */
    public function onReload($param = null)
    {
        if (isset($param['view']))
        {
            $this->fc->setCurrentView($param['view']);
        }

        if (isset($param['date']))
        {
            $this->fc->setCurrentDate($param['date']);
        }
    }

}

