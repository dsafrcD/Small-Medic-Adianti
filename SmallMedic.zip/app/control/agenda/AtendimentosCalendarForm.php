<?php

class AtendimentosCalendarForm extends TWindow
{
    protected $form;
    private $formFields = [];
    private static $database = 'consultorio';
    private static $activeRecord = 'Atendimentos';
    private static $primaryKey = 'id';
    private static $formName = 'form_AtendimentosCalendarForm';
    private static $startDateField = 'horaI';
    private static $endDateField = 'horaF';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
        parent::setSize(0.8, null);
        parent::setTitle("Agendamento");
        parent::setProperty('class', 'window_modal');

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Agendamento");

        $view = new THidden('view');

        $criteria_paciente_id = new TCriteria();
        $criteria_procedimento = new TCriteria();
        $criteria_duracao = new TCriteria();

        $filterVar = TSession::getValue("userid");
        $criteria_paciente_id->add(new TFilter('IdMedicoUser', 'like', "%{$filterVar}%")); 
        $filterVar = TSession::getValue("userid");
        $criteria_procedimento->add(new TFilter('IdMedicoUser', '=', $filterVar)); 
        $filterVar = TSession::getValue("userid");
        $criteria_duracao->add(new TFilter('IdMedicoUser', '=', $filterVar)); 

        $id = new TEntry('id');
        $IdMedicoUser = new THidden('IdMedicoUser');
        $CorStatus = new THidden('CorStatus');
        $paciente_id = new TDBCombo('paciente_id', 'consultorio', 'Pacientes', 'id', '{nome}','nome asc' , $criteria_paciente_id );
        $procedimento = new TDBCombo('procedimento', 'consultorio', 'Procedimento', 'id', '{Descricao}','Descricao asc' , $criteria_procedimento );
        $horaI = new TDateTime('horaI');
        $horaF = new TDateTime('horaF');
        $StatusConsulta = new TCombo('StatusConsulta');
        $duracao = new TDBCombo('duracao', 'consultorio', 'Duracaoconsulta', 'id', '{Descricao}','Descricao asc' , $criteria_duracao );
        $Receituario = new THtmlEditor('Receituario');
        $observacoes = new THtmlEditor('observacoes');

        $paciente_id->setChangeAction(new TAction([$this,'CarregarMedicoUser']));
        $StatusConsulta->setChangeAction(new TAction([$this,'CarregarStatusCor']));

        $horaI->setExitAction(new TAction([$this,'CarregarHoraFinal']));

        $paciente_id->addValidation("Paciente id", new TRequiredValidator()); 
        $procedimento->addValidation("Procedimento", new TRequiredValidator()); 
        $horaI->addValidation("HoraI", new TRequiredValidator()); 
        $horaF->addValidation("HoraF", new TRequiredValidator()); 
        $duracao->addValidation("Duracao", new TRequiredValidator()); 

        $id->setEditable(false);
        $procedimento->setValue(',');
        $StatusConsulta->addItems(['Concluida'=>'Concluída','Cancelada'=>'Cancelada','Faltou'=>'Faltou','Retorno'=>'Retorno','Outros'=>'Outros']);

        $horaI->setMask('dd/mm/yyyy hh:ii');
        $horaF->setMask('dd/mm/yyyy hh:ii');

        $horaI->setDatabaseMask('yyyy-mm-dd hh:ii');
        $horaF->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setSize(100);
        $horaI->setSize(150);
        $horaF->setSize(150);
        $CorStatus->setSize(200);
        $duracao->setSize('100%');
        $IdMedicoUser->setSize(200);
        $paciente_id->setSize('100%');
        $procedimento->setSize('100%');
        $StatusConsulta->setSize('100%');
        $Receituario->setSize('100%', 150);
        $observacoes->setSize('100%', 150);

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$id,$IdMedicoUser,$CorStatus],[new TLabel("Paciente:", '#ff0000', '14px', null, '100%'),$paciente_id],[new TLabel("Procedimento:", '#ff0000', '14px', null, '100%'),$procedimento],[new TLabel("Hora:", '#ff0000', '14px', null, '100%'),$horaI,new TLabel("HoraF:", '#ff0000', '14px', null, '100%'),$horaF,new TLabel("Status:", null, '14px', null),$StatusConsulta],[new TLabel("Duração:", '#ff0000', '14px', null, '100%'),$duracao]);
        $row1->layout = [' col-sm-2',' col-sm-3',' col-sm-3','col-sm-2','col-sm-2'];

        $row2 = $this->form->addFields([new TLabel("Receituario:", null, '14px', null),$Receituario],[new TLabel("Observações:", null, '14px', null, '100%'),$observacoes]);
        $row2->layout = ['col-sm-12',' col-sm-12'];

    if (empty($param['id']))
    {

    TScript::create("$(\"[name='StatusConsulta']\").closest('.fb-inline-field-container').hide()");
    //TScript::create("$(\"[name='$row2']\").closest('.fb-inline-field-container').hide()");
    TScript::create("$('label:contains(\"Status:\")').hide();");
    TScript::create("$(\"[name='Receituario']\").closest('.fb-inline-field-container').hide()");
    TScript::create("$('label:contains(\"Receituario:\")').hide();");
    TScript::create("$(\"[name='horaF']\").closest('.fb-inline-field-container').hide()");
    TScript::create("$('label:contains(\"HoraF:\")').hide();");
    } else {
    TScript::create("$(\"[name='horaI']\").closest('.fb-inline-field-container').hide()");
    TScript::create("$('label:contains(\"Hora:\")').hide();");
    TScript::create("$(\"[name='horaF']\").closest('.fb-inline-field-container').hide()");
    TScript::create("$('label:contains(\"HoraF:\")').hide();");
    TScript::create("$(\"[name='duracao']\").closest('.fb-inline-field-container').hide()");
    TScript::create("$('label:contains(\"Duração:\")').hide();");

    }

        $this->form->addFields([$view]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_ondelete = $this->form->addAction("Excluir", new TAction([$this, 'onDelete']), 'fas:trash-alt #dd5a43');
        $this->btn_ondelete = $btn_ondelete;

        parent::add($this->form);

    }

    public static function CarregarHoraFinal($param = null) 
    {
        try 
        {
            //code here

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function CarregarMedicoUser($param = null) 
    {
        try 
        {
        $object = new stdClass();
        $object->IdMedicoUser = TSession::getValue('userid');
        TForm::sendData(self::$formName, $object);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function CarregarStatusCor($param = null) 
    {
        try 
        {
        $object = new stdClass();
		  switch ($param['StatusConsulta']) {
               case 'Concluida': $object->CorStatus = '#006400'; break;
               case 'Cancelada': $object->CorStatus = '#FF0000'; break;
               case 'Faltou':    $object->CorStatus = '#8B4513'; break;
               case 'Retorno':   $object->CorStatus = '#0000FF'; break;
               case 'Outros':    $object->CorStatus = '#1C1C1C';break;
    		  }
        TForm::sendData(self::$formName, $object);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Atendimentos(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $messageAction = new TAction(['AtendimentosCalendarFormView', 'onReload']);
            $messageAction->setParameter('view', $data->view);
            $messageAction->setParameter('date', explode(' ', $data->horaI)[0]);

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            new TMessage('info', "Consulta Salva Com Sucesso", $messageAction); 

                TWindow::closeWindow(parent::getId()); 

        }
        catch (Exception $e) // in case of exception
        {
            //</catchAutoCode> 

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }
    public function onDelete($param = null) 
    {
        if(isset($param['delete']) && $param['delete'] == 1)
        {
            try
            {
                $key = $param[self::$primaryKey];

                // open a transaction with database
                TTransaction::open(self::$database);

                $class = self::$activeRecord;

                // instantiates object
                $object = new $class($key, FALSE);

                // deletes the object from the database
                $object->delete();

                // close the transaction
                TTransaction::close();

                $messageAction = new TAction(array(__CLASS__.'View', 'onReload'));
                $messageAction->setParameter('view', $param['view']);
                $messageAction->setParameter('date', explode(' ',$param[self::$startDateField])[0]);

                // shows the success message
                new TMessage('info', AdiantiCoreTranslator::translate('Record deleted'), $messageAction);
            }
            catch (Exception $e) // in case of exception
            {
                // shows the exception error message
                new TMessage('error', $e->getMessage());
                // undo all pending operations
                TTransaction::rollback();
            }
        }
        else
        {
            // define the delete action
            $action = new TAction(array($this, 'onDelete'));
            $action->setParameters((array) $this->form->getData());
            $action->setParameter('delete', 1);
            // shows a dialog to the user
            new TQuestion(AdiantiCoreTranslator::translate('Do you really want to delete ?'), $action);   
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Atendimentos($key); // instantiates the Active Record 

                                $object->view = !empty($param['view']) ? $param['view'] : 'agendaWeek'; 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

    public function onStartEdit($param)
    {
        TSession::setValue('{$detailId}_items', null);

        $this->form->clear(true);

        $data = new stdClass;
        $data->view = $param['view']; // calendar view
        $data->CorStatus = '#3a87ad';

        if ($param['date'])
        {
            if(strlen($param['date']) == '10')
                $param['date'].= ' 09:00';

            $data->horaI = str_replace('T', ' ', $param['date']);

            $horaF = new DateTime($data->horaI);
            $horaF->add(new DateInterval('PT1H'));
            $data->horaF = $horaF->format('Y-m-d H:i:s');

            $this->form->setData( $data );
        }
    }

    public static function onUpdateEvent($param)
    {
        try
        {
            if (isset($param['id']))
            {
                TTransaction::open(self::$database);

                $class = self::$activeRecord;
                $object = new $class($param['id']);

                $object->horaI = str_replace('T', ' ', $param['start_time']);
                $object->horaF   = str_replace('T', ' ', $param['end_time']);

                $object->store();

                // close the transaction
                TTransaction::close();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', '<b>Error</b> ' . $e->getMessage());
            TTransaction::rollback();
        }
    }

}

