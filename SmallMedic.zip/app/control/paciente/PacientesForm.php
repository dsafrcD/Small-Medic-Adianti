<?php

class PacientesForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'consultorio';
    private static $activeRecord = 'Pacientes';
    private static $primaryKey = 'id';
    private static $formName = 'form_PacientesForm';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        if(!empty($param['target_container']))
        {
            $this->adianti_target_container = $param['target_container'];
        }

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Pacientes");


        $IdMedicoUser = new THidden('IdMedicoUser');
        $id = new TEntry('id');
        $nome = new TEntry('nome');
        $nascimento = new TDate('nascimento');
        $sexo = new TCombo('sexo');
        $cep = new TEntry('cep');
        $endereco = new TEntry('endereco');
        $bairro = new TEntry('bairro');
        $cidade = new TEntry('cidade');
        $estado = new TEntry('estado');
        $email = new TEntry('email');
        $fone_pessoal = new TEntry('fone_pessoal');
        $fone_comercial = new TEntry('fone_comercial');
        $observacoes = new THtmlEditor('observacoes');

        $nome->setExitAction(new TAction([$this,'CarregarMedico']));
        $cep->setExitAction(new TAction([$this,'CarregarCep']));

        $nome->addValidation("Nome", new TRequiredValidator()); 
        $nascimento->addValidation("Nascimento", new TRequiredValidator()); 
        $sexo->addValidation("Sexo", new TRequiredValidator()); 
        $cep->addValidation("Cep", new TRequiredValidator()); 
        $endereco->addValidation("Endereco", new TRequiredValidator()); 
        $bairro->addValidation("Bairro", new TRequiredValidator()); 
        $cidade->addValidation("Cidade", new TRequiredValidator()); 
        $estado->addValidation("Estado", new TRequiredValidator()); 
        $fone_pessoal->addValidation("Fone pessoal", new TRequiredValidator()); 

        $id->setEditable(false);
        $nascimento->setDatabaseMask('yyyy-mm-dd');
        $sexo->addItems(['Masculino'=>'Masculino','Feminino'=>'Feminino','prefironaodizer'=>'Prefiro não dizer']);

        $cep->setMask('00000-000');
        $nascimento->setMask('dd/mm/yyyy');
        $fone_pessoal->setMask('(00) 00000-0000');
        $fone_comercial->setMask('(00) 0000-0000');

        $cep->setMaxLength(250);
        $nome->setMaxLength(250);
        $email->setMaxLength(250);
        $bairro->setMaxLength(250);
        $cidade->setMaxLength(250);
        $estado->setMaxLength(250);
        $endereco->setMaxLength(250);
        $fone_pessoal->setMaxLength(50);
        $fone_comercial->setMaxLength(50);

        $id->setSize(100);
        $cep->setSize('100%');
        $nome->setSize('100%');
        $sexo->setSize('100%');
        $email->setSize('100%');
        $bairro->setSize('100%');
        $cidade->setSize('100%');
        $estado->setSize('100%');
        $nascimento->setSize(110);
        $endereco->setSize('100%');
        $IdMedicoUser->setSize(200);
        $fone_pessoal->setSize('100%');
        $fone_comercial->setSize('100%');
        $observacoes->setSize('100%', 150);

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null, '100%'),$IdMedicoUser,$id],[new TLabel("Nome:", '#ff0000', '14px', null, '100%'),$nome],[new TLabel("Nascimento:", '#ff0000', '14px', null, '100%'),$nascimento],[new TLabel("Sexo:", '#ff0000', '14px', null, '100%'),$sexo]);
        $row1->layout = ['col-sm-2',' col-sm-6','col-sm-2',' col-sm-2'];

        $row2 = $this->form->addFields([new TLabel("Cep:", '#ff0000', '14px', null, '100%'),$cep],[new TLabel("Endereco:", '#ff0000', '14px', null, '100%'),$endereco],[new TLabel("Bairro:", '#ff0000', '14px', null, '100%'),$bairro],[new TLabel("Cidade:", '#ff0000', '14px', null, '100%'),$cidade],[new TLabel("Estado:", '#ff0000', '14px', null, '100%'),$estado]);
        $row2->layout = [' col-sm-2',' col-sm-5','col-sm-2','col-sm-2',' col-sm-1'];

        $row3 = $this->form->addFields([new TLabel("Email:", null, '14px', null, '100%'),$email],[new TLabel("Celular:", '#ff0000', '14px', null, '100%'),$fone_pessoal],[new TLabel("Comercial:", null, '14px', null, '100%'),$fone_comercial]);
        $row3->layout = [' col-sm-4',' col-sm-4',' col-sm-4'];

        $row4 = $this->form->addFields([new TLabel("Observações:", null, '14px', null, '100%'),$observacoes]);
        $row4->layout = [' col-sm-12'];

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fas:save #ffffff');
        $this->btn_onsave = $btn_onsave;
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fas:eraser #dd5a43');
        $this->btn_onclear = $btn_onclear;

        $btn_onshow = $this->form->addAction("Voltar", new TAction(['PacientesHeaderList', 'onShow']), 'fas:arrow-left #000000');
        $this->btn_onshow = $btn_onshow;

        parent::setTargetContainer('adianti_right_panel');

        $btnClose = new TButton('closeCurtain');
        $btnClose->class = 'btn btn-sm btn-default';
        $btnClose->style = 'margin-right:10px;';
        $btnClose->onClick = "Template.closeRightPanel();";
        $btnClose->setLabel("Fechar");
        $btnClose->setImage('fas:times');

        $this->form->addHeaderWidget($btnClose);

        parent::add($this->form);

        $style = new TStyle('right-panel');
        $style->width = '90% !important';   
        $style->show(true);

    }

    public static function CarregarMedico($param = null) 
    {
        try 
        {
        $object = new stdClass();
        $object->IdMedicoUser = TSession::getValue('userid');

        TForm::sendData(self::$formName, $object);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function CarregarCep($param = null) 
    {
        try 
        {
            if (!preg_match('/^[\d]{5}-?[\d]{3}$/', $param['cep'])){return;}
            $consulta = file_get_contents("https://brasilapi.com.br/api/cep/v1/".$param['cep']);
            $consulta = json_decode($consulta);
            if (json_last_error()!== JSON_ERROR_NONE or empty($consulta->street)) {return;}
            $objeto = new stdClass();
            $objeto->endereco = $consulta->street;
            $objeto->bairro   = $consulta->neighborhood;
            $objeto->cidade   = $consulta->city;
            $objeto->estado  = $consulta->state;
            TForm::sendData(self::$formName, $objeto);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Pacientes(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $loadPageParam = [];

            if(!empty($param['target_container']))
            {
                $loadPageParam['target_container'] = $param['target_container'];
            }

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            TToast::show('success', "Registro salvo", 'topRight', 'far:check-circle');
            TApplication::loadPage('PacientesHeaderList', 'onShow', $loadPageParam); 

                        TScript::create("Template.closeRightPanel();"); 

        }
        catch (Exception $e) // in case of exception
        {
            //</catchAutoCode> 

            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Pacientes($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

}

