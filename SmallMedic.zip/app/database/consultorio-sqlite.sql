PRAGMA foreign_keys=OFF; 

CREATE TABLE atendimentos( 
      id  INTEGER    NOT NULL  , 
      paciente_id int  (10)   NOT NULL  , 
      procedimento int   NOT NULL    DEFAULT ',', 
      horaI datetime   NOT NULL  , 
      horaF datetime   NOT NULL  , 
      duracao int   NOT NULL  , 
      IdMedicoUser int   , 
      observacoes text     DEFAULT NULL, 
      StatusConsulta varchar  (50)   , 
      Receituario text   , 
      CorStatus varchar  (50)   , 
 PRIMARY KEY (id),
FOREIGN KEY(paciente_id) REFERENCES pacientes(id),
FOREIGN KEY(procedimento) REFERENCES Procedimento(id),
FOREIGN KEY(duracao) REFERENCES DuracaoConsulta(id)) ; 

CREATE TABLE DuracaoConsulta( 
      id  INTEGER    NOT NULL  , 
      Descricao varchar  (250)   , 
      IdMedicoUser int   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pacientes( 
      id  INTEGER    NOT NULL  , 
      nome varchar  (250)   NOT NULL  , 
      nascimento date   NOT NULL  , 
      sexo varchar  (250)   NOT NULL  , 
      email varchar  (250)     DEFAULT NULL, 
      cep varchar  (250)   NOT NULL  , 
      endereco varchar  (250)   NOT NULL  , 
      bairro varchar  (250)   NOT NULL  , 
      cidade varchar  (250)   NOT NULL  , 
      estado varchar  (250)   NOT NULL  , 
      fone_pessoal varchar  (50)   NOT NULL  , 
      fone_comercial varchar  (50)     DEFAULT NULL, 
      observacoes text     DEFAULT NULL, 
      IdMedicoUser int   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE Procedimento( 
      id  INTEGER    NOT NULL  , 
      Descricao varchar  (250)   , 
      IdMedicoUser int   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
      system_program_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_program_id) REFERENCES system_program(id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)   NOT NULL  , 
      preference text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
      controller text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
      connection_name text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_group( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_group_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_group_id) REFERENCES system_group(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_user_program( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_program_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_program_id) REFERENCES system_program(id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id)) ; 

CREATE TABLE system_users( 
      id int   NOT NULL  , 
      name text   NOT NULL  , 
      login text   NOT NULL  , 
      password text   NOT NULL  , 
      email text   , 
      frontpage_id int   , 
      system_unit_id int   , 
      active char  (1)   , 
 PRIMARY KEY (id),
FOREIGN KEY(system_unit_id) REFERENCES system_unit(id),
FOREIGN KEY(frontpage_id) REFERENCES system_program(id)) ; 

CREATE TABLE system_user_unit( 
      id int   NOT NULL  , 
      system_user_id int   NOT NULL  , 
      system_unit_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(system_user_id) REFERENCES system_users(id),
FOREIGN KEY(system_unit_id) REFERENCES system_unit(id)) ; 

 
 
  
