CREATE TABLE atendimentos( 
      id  SERIAL    NOT NULL  , 
      paciente_id integer   NOT NULL  , 
      procedimento integer   NOT NULL    DEFAULT ',', 
      horaI timestamp   NOT NULL  , 
      horaF timestamp   NOT NULL  , 
      duracao integer   NOT NULL  , 
      IdMedicoUser integer   , 
      observacoes text     DEFAULT NULL, 
      StatusConsulta varchar  (50)   , 
      Receituario text   , 
      CorStatus varchar  (50)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE DuracaoConsulta( 
      id  SERIAL    NOT NULL  , 
      Descricao varchar  (250)   , 
      IdMedicoUser integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE pacientes( 
      id  SERIAL    NOT NULL  , 
      nome varchar  (250)   NOT NULL  , 
      nascimento date   NOT NULL  , 
      sexo varchar  (250)   NOT NULL  , 
      email varchar  (250)     DEFAULT NULL, 
      cep varchar  (250)   NOT NULL  , 
      endereco varchar  (250)   NOT NULL  , 
      bairro varchar  (250)   NOT NULL  , 
      cidade varchar  (250)   NOT NULL  , 
      estado varchar  (250)   NOT NULL  , 
      fone_pessoal varchar  (50)   NOT NULL  , 
      fone_comercial varchar  (50)     DEFAULT NULL, 
      observacoes text     DEFAULT NULL, 
      IdMedicoUser integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE Procedimento( 
      id  SERIAL    NOT NULL  , 
      Descricao varchar  (250)   , 
      IdMedicoUser integer   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_group_program( 
      id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
      system_program_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_preference( 
      id varchar  (255)   NOT NULL  , 
      preference text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_program( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      controller text   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_unit( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      connection_name text   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_group( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_group_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_program( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_program_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_users( 
      id integer   NOT NULL  , 
      name text   NOT NULL  , 
      login text   NOT NULL  , 
      password text   NOT NULL  , 
      email text   , 
      frontpage_id integer   , 
      system_unit_id integer   , 
      active char  (1)   , 
 PRIMARY KEY (id)) ; 

CREATE TABLE system_user_unit( 
      id integer   NOT NULL  , 
      system_user_id integer   NOT NULL  , 
      system_unit_id integer   NOT NULL  , 
 PRIMARY KEY (id)) ; 

 
  
 ALTER TABLE atendimentos ADD CONSTRAINT fk_atendimentos_Paciente FOREIGN KEY (paciente_id) references pacientes(id); 
ALTER TABLE atendimentos ADD CONSTRAINT fk_atendimentos_Procedimento FOREIGN KEY (procedimento) references Procedimento(id); 
ALTER TABLE atendimentos ADD CONSTRAINT fk_atendimentos_Duracao FOREIGN KEY (duracao) references DuracaoConsulta(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_group_program ADD CONSTRAINT fk_system_group_program_2 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_1 FOREIGN KEY (system_group_id) references system_group(id); 
ALTER TABLE system_user_group ADD CONSTRAINT fk_system_user_group_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_1 FOREIGN KEY (system_program_id) references system_program(id); 
ALTER TABLE system_user_program ADD CONSTRAINT fk_system_user_program_2 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_1 FOREIGN KEY (system_unit_id) references system_unit(id); 
ALTER TABLE system_users ADD CONSTRAINT fk_system_user_2 FOREIGN KEY (frontpage_id) references system_program(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_1 FOREIGN KEY (system_user_id) references system_users(id); 
ALTER TABLE system_user_unit ADD CONSTRAINT fk_system_user_unit_2 FOREIGN KEY (system_unit_id) references system_unit(id); 

  
