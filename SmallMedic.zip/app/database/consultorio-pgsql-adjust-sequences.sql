SELECT setval('atendimentos_id_seq', coalesce(max(id),0) + 1, false) FROM atendimentos;
SELECT setval('DuracaoConsulta_id_seq', coalesce(max(id),0) + 1, false) FROM DuracaoConsulta;
SELECT setval('pacientes_id_seq', coalesce(max(id),0) + 1, false) FROM pacientes;
SELECT setval('Procedimento_id_seq', coalesce(max(id),0) + 1, false) FROM Procedimento;