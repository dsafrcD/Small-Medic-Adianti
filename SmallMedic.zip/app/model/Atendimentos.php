<?php

class Atendimentos extends TRecord
{
    const TABLENAME  = 'atendimentos';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $paciente;
    private $fk_procedimento;
    private $fk_duracao;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('paciente_id');
        parent::addAttribute('procedimento');
        parent::addAttribute('horaI');
        parent::addAttribute('horaF');
        parent::addAttribute('duracao');
        parent::addAttribute('IdMedicoUser');
        parent::addAttribute('observacoes');
        parent::addAttribute('StatusConsulta');
        parent::addAttribute('Receituario');
        parent::addAttribute('CorStatus');
            
    }

    /**
     * Method set_pacientes
     * Sample of usage: $var->pacientes = $object;
     * @param $object Instance of Pacientes
     */
    public function set_paciente(Pacientes $object)
    {
        $this->paciente = $object;
        $this->paciente_id = $object->id;
    }

    /**
     * Method get_paciente
     * Sample of usage: $var->paciente->attribute;
     * @returns Pacientes instance
     */
    public function get_paciente()
    {
    
        // loads the associated object
        if (empty($this->paciente))
            $this->paciente = new Pacientes($this->paciente_id);
    
        // returns the associated object
        return $this->paciente;
    }
    /**
     * Method set_Procedimento
     * Sample of usage: $var->Procedimento = $object;
     * @param $object Instance of Procedimento
     */
    public function set_fk_procedimento(Procedimento $object)
    {
        $this->fk_procedimento = $object;
        $this->procedimento = $object->id;
    }

    /**
     * Method get_fk_procedimento
     * Sample of usage: $var->fk_procedimento->attribute;
     * @returns Procedimento instance
     */
    public function get_fk_procedimento()
    {
    
        // loads the associated object
        if (empty($this->fk_procedimento))
            $this->fk_procedimento = new Procedimento($this->procedimento);
    
        // returns the associated object
        return $this->fk_procedimento;
    }
    /**
     * Method set_DuracaoConsulta
     * Sample of usage: $var->DuracaoConsulta = $object;
     * @param $object Instance of Duracaoconsulta
     */
    public function set_fk_duracao(Duracaoconsulta $object)
    {
        $this->fk_duracao = $object;
        $this->duracao = $object->id;
    }

    /**
     * Method get_fk_duracao
     * Sample of usage: $var->fk_duracao->attribute;
     * @returns Duracaoconsulta instance
     */
    public function get_fk_duracao()
    {
    
        // loads the associated object
        if (empty($this->fk_duracao))
            $this->fk_duracao = new Duracaoconsulta($this->duracao);
    
        // returns the associated object
        return $this->fk_duracao;
    }

    
}

