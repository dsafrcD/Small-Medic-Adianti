<?php

class Duracaoconsulta extends TRecord
{
    const TABLENAME  = 'DuracaoConsulta';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('Descricao');
        parent::addAttribute('IdMedicoUser');
            
    }

    /**
     * Method getAtendimentoss
     */
    public function getAtendimentoss()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('duracao', '=', $this->id));
        return Atendimentos::getObjects( $criteria );
    }

    public function set_atendimentos_paciente_to_string($atendimentos_paciente_to_string)
    {
        if(is_array($atendimentos_paciente_to_string))
        {
            $values = Pacientes::where('id', 'in', $atendimentos_paciente_to_string)->getIndexedArray('nome', 'nome');
            $this->atendimentos_paciente_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimentos_paciente_to_string = $atendimentos_paciente_to_string;
        }

        $this->vdata['atendimentos_paciente_to_string'] = $this->atendimentos_paciente_to_string;
    }

    public function get_atendimentos_paciente_to_string()
    {
        if(!empty($this->atendimentos_paciente_to_string))
        {
            return $this->atendimentos_paciente_to_string;
        }
    
        $values = Atendimentos::where('duracao', '=', $this->id)->getIndexedArray('paciente_id','{paciente->nome}');
        return implode(', ', $values);
    }

    public function set_atendimentos_fk_procedimento_to_string($atendimentos_fk_procedimento_to_string)
    {
        if(is_array($atendimentos_fk_procedimento_to_string))
        {
            $values = Procedimento::where('id', 'in', $atendimentos_fk_procedimento_to_string)->getIndexedArray('Descricao', 'Descricao');
            $this->atendimentos_fk_procedimento_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimentos_fk_procedimento_to_string = $atendimentos_fk_procedimento_to_string;
        }

        $this->vdata['atendimentos_fk_procedimento_to_string'] = $this->atendimentos_fk_procedimento_to_string;
    }

    public function get_atendimentos_fk_procedimento_to_string()
    {
        if(!empty($this->atendimentos_fk_procedimento_to_string))
        {
            return $this->atendimentos_fk_procedimento_to_string;
        }
    
        $values = Atendimentos::where('duracao', '=', $this->id)->getIndexedArray('procedimento','{fk_procedimento->Descricao}');
        return implode(', ', $values);
    }

    public function set_atendimentos_fk_duracao_to_string($atendimentos_fk_duracao_to_string)
    {
        if(is_array($atendimentos_fk_duracao_to_string))
        {
            $values = Duracaoconsulta::where('id', 'in', $atendimentos_fk_duracao_to_string)->getIndexedArray('Descricao', 'Descricao');
            $this->atendimentos_fk_duracao_to_string = implode(', ', $values);
        }
        else
        {
            $this->atendimentos_fk_duracao_to_string = $atendimentos_fk_duracao_to_string;
        }

        $this->vdata['atendimentos_fk_duracao_to_string'] = $this->atendimentos_fk_duracao_to_string;
    }

    public function get_atendimentos_fk_duracao_to_string()
    {
        if(!empty($this->atendimentos_fk_duracao_to_string))
        {
            return $this->atendimentos_fk_duracao_to_string;
        }
    
        $values = Atendimentos::where('duracao', '=', $this->id)->getIndexedArray('duracao','{fk_duracao->Descricao}');
        return implode(', ', $values);
    }

    
}

