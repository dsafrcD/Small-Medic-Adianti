<?php
return [
    'host' => "", 
    'user' => "", 
    'pass' => "", 
    'type' => "sqlite", 
    'port' => "", 
    'name' => "app/database/consultorio.db", 
    'fkey' => "0", 
    'prep' => "1", 
    'slog' => "SystemSqlLogService", 
];